import cv2

print(cv2.getBuildInformation())
print "\n--------------------------------------------------------------\n\n"

vcap = cv2.VideoCapture("rtsp://freja.hiof.no:1935/rtplive/_definst_/hessdalen03.stream")
print(vcap.isOpened())
while(1):
    ret, frame = vcap.read()
    cv2.imshow('VIDEO', frame)
    cv2.waitKey(1)
