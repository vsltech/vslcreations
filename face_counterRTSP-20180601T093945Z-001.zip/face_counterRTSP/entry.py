#CODED BY VSL Creations | email@vslcreations.com

import cv2,sys,os,os.path
import ftplib,datetime
import threading,csv
import urllib2,ssl,time
import numpy as np



offset=50
#eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
font = cv2.FONT_HERSHEY_SIMPLEX

imgid = 0
imgid1 = 0
for line in open('in/logentry.txt', 'r'):
    imgid=int(line)

if imgid==0:
    imgid = 1
print "Current IMG ID:",imgid

imgid1 = imgid
ext = ".jpg"
counter = 0
running = 1
finalimgid = 0

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def ftp():
        global running,finalimgid,imgid1
	imgid = imgid1
        global ctx

        while True:
		#time.sleep(0.2)
		#print 'in/entryimg-'+str(imgid)+ext
		if os.path.exists('in/entryimg-'+str(imgid)+ext):
			session = ftplib.FTP('ranjandentalclinic.com','api@ranjandentalclinic.com','vslcreations.com')       
			file = open('in/entryimg-'+str(imgid)+ext,'rb')                  # file to send
			filedir = 'STOR '+'in/entryimg-'+str(imgid)+ext
			session.storbinary(filedir, file)     # send the file
			#print 'in/entryimg-'+str(imgid1)+ext+' | STORED TO SERVER'
			file.close()                                    # close file and FTP
			session.quit()
			intime = str(datetime.datetime.now().strftime("%y-%m-%d_%H-%M-%S"))
		
			apiurl = "https://smartfacerec.ddns.net/api/entryapi.php?url=http://www.ranjandentalclinic.com/api/in/entryimg-"+str(imgid)+ext+"&intime="+intime+"&id="+str(imgid)
			#print apiurl
			
			try:
				response = urllib2.urlopen(apiurl, context=ctx)
				data = response.read()
				print data
				if data == "FACE EXISTS":
					os.remove('in/entryimg-'+str(imgid)+ext)
			except urllib2.HTTPError:
				pass

			imgid = imgid+1
			finalimgid = imgid
			#print "entryimg-"+str(imgid1)+ext+" | FACE DETECTED & STORED TO CLOUD"

		if running==0:
		   break
		
		else:
			print "Waiting for FACE...\n"
			while True:
				if os.path.exists('in/entryimg-'+str(imgid)+ext):
					break
		


def variance_of_laplacian(image):
	# compute the Laplacian of the image and then return the focus
	# measure, which is simply the variance of the Laplacian
	return cv2.Laplacian(image, cv2.CV_64F).var()



host = raw_input("ENTER CAM URL (e.g: rtsp://freja.hiof.no:1935/rtplive/_definst_/hessdalen03.stream)=")
if len(sys.argv)>1:
    host = "'"+sys.argv[1]+"'"

print 'Streaming: ' + host
cam = cv2.VideoCapture(host)

#multi-threading
t = threading.Thread(target=ftp)
t.start()

# keep looping until the 'q' key is pressed
while True:
        imgname = 'entryimg-'

        (grabbed, i) = cam.read()
        if not grabbed:
            break

        small_frame = cv2.resize(i, (640, 400))
                
        img = small_frame
        orig_img = img.copy()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	fm = variance_of_laplacian(gray)
	#print type(fm)
	if fm>20:
		cv2_faces = face_cascade.detectMultiScale(gray, 1.3, 5)
		for (x,y,w,h) in cv2_faces:
		    cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)                  
		    cv2.putText(img,'FACE DETECTED',(x,y), font, 1,(255,255,255),2,cv2.LINE_AA)     
		    counter = counter+0.1
		    roi_color = orig_img[y:y+h, x:x+w]
		                #print counter
			
		cv2.imshow('img',img)
		#Store img if face detected
		if counter>1.5:
		    imgname = imgname + str(imgid) + ext
		    cv2.imwrite('in/'+imgname,roi_color)
		    #ftp()
		        
		    imgid = imgid+1 
		    imgname = 'entryimg-'
		    counter = 0
                         
        
        if cv2.waitKey(10) & 0xff == ord('q'):
            running = 0
            break

f = open('in/logentry.txt', 'w')
f.write(str(finalimgid))
f.close()
cv2.destroyAllWindows()
