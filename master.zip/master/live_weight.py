import cv2
import numpy as np
import imutils
import serial,time

ser = serial.Serial(
            port='COM4',\
            baudrate=9600,\
            parity=serial.PARITY_NONE,\
            stopbits=serial.STOPBITS_ONE,\
            bytesize=serial.EIGHTBITS,\
                timeout=0)


print"connected to: " + ser.portstr
#wt="0.00"
def weight():
        wt=ser.readline()
        #time.sleep(2)
        #wt1=float(ser.read(5))
        

        

# load video
cap = cv2.VideoCapture(0)
#cap.set(cv2.cv.CV_CAP_PROP_FPS, 10)
while(cap.isOpened()):
        ret, image = cap.read()
        image = imutils.resize(image, width=600)
        img_rgb = image
        img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

        template = cv2.imread('box5.png',0)
        w, h = template.shape[::-1]

        res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
        threshold = 0.8
        loc = np.where( res >= threshold)
        msg = "Place Box"
        cv2.rectangle(img_rgb, (210,200), (210 + 58, 200 + 51), (0,0,255), 2)
        cv2.putText(img_rgb, msg, (190, 270), cv2.FONT_HERSHEY_SIMPLEX,0.5, (0, 0, 255), 2)

        for pt in zip(*loc[::-1]):
            #cv2.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0,255,0), 2)
            cv2.rectangle(img_rgb, (210,200), (210 + 58, 200 + 51), (0,255,0), 2)
            wt=ser.readline()
            wt=wt.strip('\n')
            msg = "Weight: "+wt
            cv2.putText(img_rgb, msg, (pt[0]-50, pt[1]), cv2.FONT_HERSHEY_SIMPLEX,1, (0, 255, 0), 2)
            
            #if(wt1-wt)>0.1:
            #if(wt!="NULL"):    
            #print "Weight: "+wt
            
        cv2.imshow('Detected',img_rgb)
        #print "Weight: "+wt
        if cv2.waitKey(1) & 0xff == ord('q'):
                break
cap.release() 
cv2.destroyAllWindows()
ser.close()
