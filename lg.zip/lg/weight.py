#! /usr/bin/python

import time
import serial

ser = serial.Serial(
            port='/dev/ttyUSB0',\
            baudrate=9600,\
            parity=serial.PARITY_NONE,\
            stopbits=serial.STOPBITS_ONE,\
            bytesize=serial.EIGHTBITS,\
                timeout=0)

print"connected to: " + ser.portstr
wt1 = 0.0

def isfloat(value):
        try:
    		float(value)
    		return True
  	except:
    		return False


while True:
	wt=ser.readline()
	#wt=wt.strip('\n')
	if(isfloat(wt)):
		wt1=float(wt)
		print wt1
	time.sleep(0.2)