#! /usr/bin/python

from PyQt4 import QtCore, QtGui, uic
import sys,time,os


form_class = uic.loadUiType("welcome.ui")[0]

class MyWindowClass(QtGui.QMainWindow, form_class):
    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setupUi(self)     
 
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(1)
	
	current_time = QtCore.QDateTime.currentDateTime()
 	self.timeEdit.setDateTime(current_time)
	parameter1 = QtCore.QTime.currentTime()
	self.timeEdit_2.setDateTime(current_time)
	parameter2 = QtCore.QTime.currentTime()
	self.timeEdit_3.setDateTime(current_time)
 
    def update_frame(self):
	global stats1
	current_time = QtCore.QDateTime.currentDateTime()
 	self.timeEdit.setDateTime(current_time)
	parameter1 = QtCore.QTime.currentTime()
	self.timeEdit_2.setDateTime(current_time)
	parameter2 = QtCore.QTime.currentTime()
	self.timeEdit_3.setDateTime(current_time)
		

if __name__ == "__main__": 
	import sys
	app = QtGui.QApplication(sys.argv)
	w = MyWindowClass(None)
	w.setWindowTitle('LG- Monitoring System')
	w.show()
	app.exec_()