<!--Copyright VSL Creations: http://www.vslcreations.com-->
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Brain Game Simulator using NeuroSky Mindwave- EEG via BLE | Best consumer electronics & embedded software in Bengaluru">
    <meta name="author" content="VSL Creations">
    <link rel="icon" href="img/favicon.png">
    <title>Brain Game Simulator- VSL Creations</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118206406-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118206406-1');
</script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </head>

  <body style="background: url(img/bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">

     <nav class="navbar navbar-default navbar-fixed-top">
<div class="topnav" id="myTopnav">    
     <a href="index.php" class="active"><img src="img/favicon.png"  width="30px"/></a>
      <a href="register.php">Register</a>
      <a href="login.php">Login</a>
      <a href="profile.php">Profile</a>
<a href="" rel="nofollow"><img width = "100px" src="img/dl.png"></a>
<a href="https://transactions.sendowl.com/products/77844085/E4E427A7/purchase" rel="nofollow"><img width = "75px" src="https://transactions.sendowl.com/assets/external/buy-now.png"></a>
<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
      </div>

    </nav>

<div class="container">
<div class="jumbotron">
    <br/><h1><b>Brain Game Simulator</b></h1>
	
    <a class="btn btn-lg btn-primary" href="register.php" role="button">Register</a>&nbsp;&nbsp;&nbsp;&nbsp;
    <a class="btn btn-lg btn-success" href="login.php" role="button">Login</a>
    &nbsp;&nbsp;&nbsp;&nbsp;<a href="" rel="nofollow"><img width = "150px" src="img/dl.png"></a>
<hr>
<h2><b>NeuroSky Mindwave2- BLE</b> <br> Enhancing Gaming Experience</h2>	
<img src="img/BGS.jpg" width="auto" height="auto" /><hr>
<p><iframe width="560" height="315" src="https://www.youtube.com/embed/NPr9M-b2EQc" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></p>
	<p><iframe width="560" height="315" src="https://www.youtube.com/embed/Ft7ZFXsT43w" frameborder="0" allowfullscreen></iframe>
    <br/><i>License to start free trial</i></p>
<div id="sfcq9ntrtx7n7m489gxy7s6pym187j37lcn"></div>


</div>   
</div> <!-- /container -->
  

</body></html>

