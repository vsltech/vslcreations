# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.core.files.storage import FileSystemStorage
from django.http import JsonResponse
from django.views.generic import TemplateView
from django.shortcuts import render  
from django.template import loader  
from django.http import HttpResponse  

from main.detect import get_face_detect_data


def upload_file(image):
    fs = FileSystemStorage()
    filename = fs.save(image.name, image)
    uploaded_file_url = fs.path(filename)
    return uploaded_file_url

# Create your views here. 
def how_view(request):  
   template = loader.get_template('how.html') # getting our template  
   return HttpResponse(template.render())       # rendering the template in HttpResponse  

def price_view(request):  
   template = loader.get_template('pricing.html') # getting our template  
   return HttpResponse(template.render())       # rendering the template in HttpResponse  
     
class ImageFaceDetect(TemplateView):
    template_name = 'register.html'

    def post(self, request, *args, **kwargs):
        data = request.POST.get('image')
        try:
            image_data = get_face_detect_data(data)
            if image_data:
                return JsonResponse(status=200, data={'image': image_data, 'message': 'Face detected'})
        except Exception as e:
            pass
        return JsonResponse(status=400, data={'errors': {'error_message': 'No face detected'}})


class LiveVideoFaceDetect(TemplateView):
    template_name = 'login.html'

    def post(self, request, *args, **kwargs):
        return JsonResponse(status=200, data={'message': 'Face detected'})
