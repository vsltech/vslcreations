from django.conf.urls import url

from main.views import ImageFaceDetect, LiveVideoFaceDetect,how_view,price_view

urlpatterns = [
    url(r'^pricing/$', price_view, name='pricing'),
    url(r'^how/$', how_view, name='how'),
    url(r'^register/$', ImageFaceDetect.as_view(), name='image'),
    url(r'^login/$', LiveVideoFaceDetect.as_view(), name='live_video'),
]
