#!/usr/bin/python
import MySQLdb,datetime,time,sys


lcl = 0.0
ucl = 0.0
ucl_rng = 0.0
lcl_rng = 0.0
frequency = 0
checkpointno = 0
checkpoint_value = 0.0
dateTime = datetime.datetime.now()
checkpoint_value_check = ""
colour_code = ""
shiftstarttime = ""
shiftendtime = ""
timeslot = "08:00AM"
avg = 0.0
rng = 0.0
 
db = MySQLdb.connect(host="10.101.32.170",  # your host 
                     user="pcbauto",       # username
                     passwd="password",     # password
                     db="timecheck")   # name of the database
 
# Create a Cursor object to execute queries.
cur = db.cursor()

# Select data from table using SQL query.
cur.execute("SELECT * FROM checkpoints where parameter_title='Gel Time Head L MC-1'")
 
# print the first and second columns      
for row in cur.fetchall() :
	lcl= float(row[4])
	ucl=float(row[5])
	frequency=int(row[17])
	checkpointno=int(row[2])

	
print lcl,ucl,frequency, checkpointno,dateTime   
#sys.exit()

try:
	cur.execute("INSERT INTO `checkpoints_response` (`cr_id`, `checkpoint_id`, `lcl`, `ucl`, `2cl`, `1cl`, `-2cl`, `-1cl`, `centerline`, `ucl_rng`, `lcl_rng`, `cl_rng`, `machine_name`, `checkpoint_value`, `checkpoint_value_check`, `date`, `colour_code`, `time_slot`, `avg`, `rng`, `na`) VALUES (NULL, %s, %s, %s, '0', '0', '0', '0', '0', '0', '0', '0', '0', %s, %s, %s, '#ffff', %s, '0', '0', '0')",(checkpointno,lcl,ucl,checkpoint_value,checkpoint_value_check,dateTime,timeslot))
   	db.commit()
	print "inserted"
except:
	db.rollback()
	print "error"


