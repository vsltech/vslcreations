#! /usr/bin/python

from PyQt4 import QtCore, QtGui, uic
import sys,time,os,subprocess

counter = time.time()
form_class = uic.loadUiType("welcome.ui")[0]


class MyWindowClass(QtGui.QMainWindow, form_class):
    def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setupUi(self)     
        
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(1)
	

	current_time = QtCore.QDateTime.currentDateTime()
 	self.timeEdit.setDateTime(current_time)
	parameter1 = QtCore.QTime.currentTime()
	self.timeEdit_2.setDateTime(current_time)
	parameter2 = QtCore.QTime.currentTime()
	self.timeEdit_3.setDateTime(current_time)
 
    def update_frame(self):
	global stats1
	global counter
	current_time = QtCore.QDateTime.currentDateTime()
	#current_time = QtCore.QDateTime()
 	self.timeEdit.setDateTime(current_time)
	parameter1 = QtCore.QTime(8, 00, 00, 000)
	self.timeEdit_2.setTime(parameter1)
	parameter2 = QtCore.QTime(11, 00, 00, 000)
	self.timeEdit_3.setTime(parameter2)
	if(time.time()-counter) > 6: 	
		print "10secs"
		subprocess.call(['python','/home/pi/lg/main.py'])
		counter = time.time()

if __name__ == "__main__": 
	import sys
	app = QtGui.QApplication(sys.argv)
	w = MyWindowClass(None)
	w.setWindowTitle('LG- Monitoring System')
	w.show()
	app.exec_()
