import sys,time,os

os.system("python welcome.py")
time.sleep(3)
os.system("python main.py")
