<?php


$id =  $_GET['id'];
$pass1 =  $_GET['pass'];

$server ="localhost";
$user = "vsltech";
$pass ="vslcreations.com";
$db = "gamesimulator";

$conn = new mysqli($server,$user,$pass,$db);

if($conn->connect_error)
{
	die("Connection failed: " . $conn_connect_error);
}
//echo "Connected<br>";
$sql = "select * from sgs where userid='".$id."' and pass='".$pass1."'";

$result = $conn->query($sql);
while($row = $result->fetch_assoc()){

	$macid = $row['macid'];
	$date1 = new DateTime($row['regdate']);
	$date2 = new DateTime($row['expdate']);
	//$totaltime = $date1->diff($date2)->format("%y-%m-%d %h:%i:%s");
	$days = $date1->diff($date2)->format("%d");
	
}
//echo $totaltime;
echo $days."-".$macid;

?>
