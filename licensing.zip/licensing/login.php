<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php
if(isset($_POST["submit"]))
{

    $userid = $_POST["id"]; 
    $passd = $_POST["pass"]; 

$server ="localhost";
$user = "vsltech";
$pass ="vslcreations.com";
$db = "gamesimulator";

$conn = new mysqli($server,$user,$pass,$db);

if($conn->connect_error)
{
	die("Connection failed: " . $conn_connect_error);
}
$userid1 = '-1';
$sql = "select * from sgs where userid='".$userid."'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
	$userid1 = $row['userid'];
	
}
    if($userid1!='-1')
    {   
        session_start(); 
		$_SESSION['accountid']=$userid1;
        header("Location: profile.php");
    }
    else
    {
        echo '<script language="javascript">alert("ID/Password Wrong!\nPlease try again!")</script>';
    }
}
?>
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Licensing- VSL Creations</title>
<!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/styles.css" rel="stylesheet">
      <link href="css/signin.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        }
        </script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  </head>
<body style="background: url(img/bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">
     <nav class="navbar navbar-default navbar-fixed-top">
        <div class="topnav" id="myTopnav">
          <a href="index.php" class="active"><img src="img/favicon.png"  width="25px"/></a>
          <a href="index.php">Register</a>
          <a href="login.php">Login</a>
          <a href="profile.php">Profile</a>
          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        </div>
    </nav>
    <div class="container" style="min-height:auto;">
     <form class="form-signin" action="" method="POST" enctype="multipart/form-data">
        
        <label class="form-control"><img width="200px" src="img/lic.png" class="img-rounded img-responsive"/><hr><h2><b>Get License Key</h2></label>    
        <input id="id" name="id" class="form-control" placeholder="Enter ID" required="yes" type="text" maxlength="12" minlength="5">
	     <input id="pass" name="pass" class="form-control" placeholder="Enter Password" required="yes" type="password" maxlength="12" minlength="8">
    	<label class="form-control"><i>Remember your id/pass for login</i></label>
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Login</button>
      </form>
    </div> <!-- /container -->
</body>
</html>
