<?php
	if(isset($_POST['submit']))
	{

		$email = $_POST["eid"];
		$mob = $_POST["mob"];
		$pin = $_POST["pin"];
		$address = $_POST["address"];
		$qty = $_POST["qty"];
		$filament = $_POST["filament"];
		$color = $_POST["label_color"];
		$weight = $_POST["label_weight"];
		$cost = $_POST["label_cost"];	
		$reff = $_POST["reff"];	
		if(is_dir("uploads") === false)
		    mkdir("uploads");

		$t = time();
		$target_file = "uploads/".$mob."_".$t.".stl";

		move_uploaded_file($_FILES["file"]["tmp_name"],$target_file); 
		$stlfile = $target_file;
		//echo '<script>alert("'.$stlfile.'")</script>';
		
	 

$server ="166.62.10.138";
$user = "vsltech";
$pass ="vslcreations.com";
$db = "gamesimulator";

$conn = new mysqli($server,$user,$pass,$db);

if($conn->connect_error)
{
	die("Connection failed: " . $conn_connect_error);
}
//echo "Connected<br>";
$sql = "insert into 3dprint (id,color,filament,weight,cost,qty,email,mob,pin,address,totalcost,date1,stlfile,reff) values(NULL,'$color','$filament','$weight','$cost','$qty','$email','$mob','$pin','$address',NULL,NULL,'$stlfile','$reff')";
//echo $sql;
   
    if($conn->query($sql)===TRUE)
    {   
        echo '<script>alert("Quotation Request Sent!")</script>';
        echo("<script>window.location = 'index.php';</script>");
    }
    else
    {
        echo '<script language="javascript">alert("ERROR!\nPlease try again!")</script>';
    }
}

?>


<!--Copyright VSL Creations: http://www.vslcreations.com-->
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>3D Printing Service- VSL Creations</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118206406-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118206406-1');
</script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

<script src="stl_viewer.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
  	<script>


        var _URL = window.URL || window.webkitURL;
            $(document).ready(function(){
                $('input[type="file"]').change(function(e){
                    var fileName = e.target.files[0].name;
                    //Remove comments to add size limits
		    var size = e.target.files[0].size;

                    if (!fileName.match(/(?:stl|STL)$/)){
                        alert('File "' + fileName +  '" is invalid!\nPlease Select Valid STL Model');
						stl_viewer.remove_model(0);
                    }
                if(size>50000000)
                {
                    alert('File "' + fileName +  '" exceeded size limit!\nPlease select less than 50mb');
					stl_viewer.remove_model(0);
                }
                });
            });


      var volg=0;  
      function load_prog(load_status, load_session)
        {
            var loaded=0;
            var total=0;
            
            //go over all models that are/were loaded
            Object.keys(load_status).forEach(function(model_id)
            {
                if (load_status[model_id].load_session==load_session) //need to make sure we're on the last loading session (not counting previous loaded models)
                {
                    loaded+=load_status[model_id].loaded;
                    total+=load_status[model_id].total;
                    
                    //set the relevant model's progress bar
                    document.getElementById("pb"+model_id).value=load_status[model_id].loaded/load_status[model_id].total;
                }
            });
            
            //set total progress bar
            document.getElementById("pbtotal").value=loaded/total;
			
        }    

			function myFunction() {
				var x = document.getElementById("myTopnav");
				if (x.className === "topnav") {
					x.className += " responsive";
				} else {
					x.className = "topnav";
				}
			}

			function calc()
			{
				var vol = JSON.stringify(stl_viewer.get_model_info(0));
				var volData = JSON.parse(vol);
				volg = (volData.volume / 1000);
				volg = volg.toFixed(3);
				document.getElementById("label_weight").value= volg;				
				var filament = document.getElementById("filament").value;
				if(filament=="PLA")
					{var totalcost = volg * 8;}
				else
					{var totalcost = volg * 10;}
				totalcost = totalcost + totalcost * 0.5;
				totalcost = totalcost.toFixed(2);				
				document.getElementById("label_cost").value= totalcost;
				alert("Parameters Changed!\nPlease Ask for final quotation");
			}		
			function set_color(o,o_color,colorid)
			{
				stl_viewer.set_color(0,o_color);
				document.getElementById("label_color").value= colorid;
				calc();

			}
				
			function load_model(filess)
			{
				stl_viewer.remove_model(0);				
				stl_viewer.add_model({id:0, local_file:filess});
				//stl_viewer.rotate(0,0.5,0,0);
				//stl_viewer.animate_model(0, {delta:{x:50, msec:10000, loop:true}} );
				calc();

			}

	</script>

  </head>

  <body style="background: url(img/bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">

     <nav class="navbar navbar-default navbar-fixed-top">
<div class="topnav" id="myTopnav">    
     <a href="index.php" class="active"><img src="img/favicon.png"  width="30px"/>Order Online</a>
<a href="tel:+919828614330">Call</a>
<a href="mailto:email@vslcreations.com">Email</a>
<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
      </div>

    </nav>

<div class="container">
<div class="jumbotron">
<h2><b>Estimate 3D Printing Cost- Upload Your .STL Model</b></h2>	

<form class="form-signin" action="" method="POST" enctype="multipart/form-data" align="left"> 

<table class="table table-bordered table-dark">
<tr>
<td>
<input type="file" name="file" style="border: 2px solid #ccc;display: inline-block;padding: 6px 12px;cursor: pointer;" onchange='load_model(this.files[0])' accept="*.*">    			
						<table>
							<tr>
								<td id="cpal">
									<div class="cbar" id="black_color" onclick="set_color(this,'#000010','Black');" style="background:#000000;"></div>
									<div class="cbar" id="grey_color" onclick="set_color(this,'#808080','Grey');" style="background:#808080;"></div>
									<div class="cbar" id="white_color" onclick="set_color(this,'#FFFFFF','White');" style="background:#FFFFFF;"></div>
									<div class="cbar" id="gold_color" onclick="set_color(this,'#D4AF37','Gold');" style="background:#FFD700;"></div>
									<div class="cbar" id="blue_color" onclick="set_color(this,'#0000FF','Blue');" style="background:#0000FF;"></div>
									<div class="cbar" id="orange_color" onclick="set_color(this,'#FF4500','Orange');" style="background:#FF4500;"></div>
									<div class="cbar" id="green_color" onclick="set_color(this,'#00FF00','Green');" style="background:#00FF00;"></div>
									<div class="cbar" id="red_color" onclick="set_color(this,'#FF0000','Red');" style="background:#FF0000;"></div>
									<div class="cbar" id="yellow_color" onclick="set_color(this,'#FFFF00','Yellow');" style="background:#FFFF00;"></div>
												
								</td>
								
							</tr>
						</table>
<!--<iframe id="vs_iframe" src="https://www.viewstl.com/?embedded&shading=smooth&color=black" style="border:0;margin:0;width:100%;height:300%;"></iframe> -->
      <div id="stl_cont" style="height:450px;margin:0 auto;"></div>
<progress id="pb0" value="0" max="1"></progress>

        <script src="stl_viewer.min.js"></script>        
        <script>
            var stl_viewer=new StlViewer
            (
                document.getElementById("stl_cont"),
                {
                    loading_progress_callback:load_prog,
                    zoom:80                    
                }
            );
			stl_viewer.set_drag_and_drop(true);
			
        </script>
        
       

    


</td>
</tr>
</table>     
     
        <label class="form-control">
Cost per gram PLA: Rs 8.00<br>   
Cost per gram ABS: Rs 10.00<br>
Cost of consumables: 10%<br>
Cost of electricity: 20%<br>
Cost of repairs & upgrades: 20%</br> 
<select id ="filament" name="filament" class="form-control" onchange="calc()">
	<option value="PLA">PLA- Polylactic Acid</option>
	<option value="ABS">ABS- Acrylonitrile Butadiene Styrene</option>
</select>
<label class="form-control">Filament Color: <input id="label_color" name="label_color" value="Grey"></label>
<label class="form-control">Weight(in grams): <input id="label_weight" name="label_weight" value="0"></label>
<label class="form-control">Unit Cost Estimated(INR): <input id="label_cost"  name="label_cost" value="0.00"></label>
<button class="btn btn-lg btn-success btn-block" onclick="calc()">Estimate Cost</button>
<p align="center">Please allow us to evaluate & estimate your 3D Model for final quotation which may take upto 24-36hrs.</p>
<hr>
<input pattern="\d*" id="qty" name="qty" class="form-control" placeholder="Enter Quantity" required="yes" type="text">

<input id="eid" name="eid" class="form-control" placeholder="Enter Email ID" required="yes" type="email">
        <input id="mob" name="mob" class="form-control" placeholder="Enter Mobile" required="yes" type="text" maxlength="15" minlength="10">
	     <input id="pin" name="pin" class="form-control" placeholder="Enter Area PIN" required="yes" type="text" maxlength="6" minlength="6">
        <input id="address" name="address" class="form-control" placeholder="Enter Shipping Address" required="yes" type="textarea" minlength="1">
<hr>
<input id="reff" name="reff" class="form-control" placeholder="Enter Referral Email/Mob" required="yes" type="textarea" minlength="1">
 <i>(*Please note the final price may vary depending on the print complexity, print time, filament color/type, shipping charges)</i>   	
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Ask Final Quotation</button>
</form>

</p>	<hr>

    <br/><i>Copyright <a href="http://www.vsltech.co.in">VSL Creations</a>&copy;2018. All Rights Reserved.</i></p>


</div>   
</div> <!-- /container -->
  

</body></html>

