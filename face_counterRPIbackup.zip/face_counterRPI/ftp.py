import ftplib

imgid1 = 0

session = ftplib.FTP('ranjandentalclinic.com','api@ranjandentalclinic.com','vslcreations.com')
file = open('test.jpg','rb')                  # file to send
filedir = 'STOR '+'cashcounter/entryimg-'+str(imgid1)+'.jpg'
session.storbinary(filedir, file)     # send the file
print 'in/entryimg-'+str(imgid1)+'.jpg'+' | STORED TO SERVER'
imgid1 = imgid1+1
	
file.close()                                    # close file and FTP
session.quit()