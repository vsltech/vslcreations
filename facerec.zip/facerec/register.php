<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php

$filename =  'unknown.jpg';
$filepath = 'unknown_people/';
move_uploaded_file($_FILES['webcam']['tmp_name'], $filepath.$filename);
sleep(3);
$target_file = "uploads/unknown.jpg";
copy($filepath.$filename,$target_file);

if(isset($_POST["submit"]))
{
	 //Calling backend to recognize face: compares known_people & unknown_people folder
	$command = escapeshellcmd('python detect9828614330007.py');
	//returns image file name from known_people
	$output = (string)shell_exec($command);
//deleting unknown.jpg/png image to avoid conflicts for login again!
unlink('unknown_people/unknown.jpg');

    if(strpos($output,'unknown_person') === false)
    {

       $outputimg = explode('.',$output);
        echo '<script language="javascript">';
        echo 'alert("FACE already registered! \n Please login!")';
        echo '</script>';
	header("Location: login.php");	
    }
    else
    {

		$adhar = $_POST["adharid"]; 
		
		$known_people = "known_people/".$adhar.".jpg";   
		//creating dataset of known_people in local server
		move_uploaded_file($target_file, $known_people);   

		if(copy($target_file,$known_people))
		{   
			$server ="localhost";
			$user = "vsltech";
			$pass ="vslcreations.com";
			$db = "gamesimulator";

			$conn = new mysqli($server,$user,$pass,$db);

			if($conn->connect_error)
			{
				die("Connection failed: " . $conn_connect_error);
			}
			//echo "Connected<br>";
			$sql = "insert into facerec_u (faceid,imgurl) values('".$adhar."','".$known_people."')";
			//echo $sql;
			   
				if($conn->query($sql)===TRUE)
				{   
					echo '<script language="javascript">alert("FaceID:'.$adhar.'\nSuccessfully Registered!\nPlease login!")</script>';
					echo("<script>window.location = 'login.php';</script>");
				}
				else
				{
					unlink($known_people);
					echo '<script language="javascript">alert("FaceID:'.$adhar.'\nAlready registered!\nPlease try different FaceID!")</script>';
				}

			unlink($target_file);
		}
		else
		{
			unlink($target_file);
		    echo '<script language="javascript">alert("System Error!\nTry Again!")</script>';        
		    echo("<script>window.location = 'register.php';</script>");
		   
		}
	
    }

}

?>
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Register Face- Smart FaceRecognition System</title>
<!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/styles.css" rel="stylesheet">
      <link href="css/signin.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        }
        </script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script type="text/javascript">
        var _URL = window.URL || window.webkitURL;
            $(document).ready(function(){
                $('input[type="file"]').change(function(e){
                    var fileName = e.target.files[0].name;
                    //Remove comments to add size limits
		    var size = e.target.files[0].size;
                    //var file = e.target.files[0];
                    
		    /*var img = new Image();
                    img.onload = function () {
                        if(this.width!=160 || this.height!=200){
                            alert('File '+fileName+': '+this.width + 'X' + this.height+' is incorrected!\nPlease select 160X200 resolution!');
                            }
                     };
                    img.src = _URL.createObjectURL(file); */
                    if (!fileName.match(/(?:jpg|JPG)$/)){
                        alert('File "' + fileName +  '" is invalid!\nPlease Select Valid jpg Image');
                    }
                if(size>2000000)
                {
                    alert('File "' + fileName +  '" exceeded size limit!\nPlease select less than 2mb');
                }
                });
            });
        </script>
	<script type="text/javascript" src="js/webcam.js"></script>
	<!-- Configure a few settings and attach camera -->

  </head>
<body style="background: url(img/bg.jpeg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">
     <nav class="navbar navbar-default navbar-fixed-top">
        <div class="topnav" id="myTopnav">
          <a href="index.php" class="active"><img src="img/favicon.png"  width="25px"/></a>
<a href="features.php">WHY?</a>
          <a href="register.php">Register</a>
          <a href="login.php">Login</a>
          <a href="profile.php">Profile</a>
<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        </div>
    </nav>
	<table border=1><tr><td align="center">Please remove eyeglasses | Keep face straight | Provide sufficient light</td></tr>
    <tr><td><div id="my_camera"></div></td></tr>
    </table>    
<form action="" method="POST" enctype="multipart/form-data">        
        <input id="adharid" name="adharid" class="form-control" placeholder="Enter Unique Face ID" required="yes" type="text" pattern="\d*" maxlength="12" minlength="12">
	    <!--<input type="file" name="file" class="form-control" multiple accept='image/*'> -->

    	<!--<strong><i>(*Note: Please upload your color(RGB) passport-size photo.Size Limit: 2mb)</i></strong>-->
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit" onClick="take_snapshot()">Register</button>
      </form>
	<script language="JavaScript">
var w = window.innerWidth;
if(w>640){ w = 640;h=(w/2)*1.5;}

if(w<640)
{
	w=270;
	h=340;
}
		Webcam.set({
			width: w,
			height: h,
			image_format: 'jpeg',
			jpeg_quality: 90
		});
		Webcam.attach( '#my_camera' );
	</script>
	<!-- Code to handle taking the snapshot and displaying it locally -->
	<script language="JavaScript">
		function take_snapshot() {
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				Webcam.upload( data_uri, 'register.php');	
			} );
		}
	</script>
</body>
</html>
