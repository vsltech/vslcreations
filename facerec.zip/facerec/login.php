<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php
$filename =  'unknown.jpg';
$filepath = 'unknown_people/';
move_uploaded_file($_FILES['webcam']['tmp_name'], $filepath.$filename);
if (isset($_POST['submit']))
{
 //Calling backend to recognize face: compares known_people & unknown_people folder
$command = escapeshellcmd('python detect9828614330007.py');
//returns image file name from known_people
$output = (string)shell_exec($command);
//deleting unknown.jpg/png image to avoid conflicts for login again!
unlink('unknown_people/unknown.jpg');
    if(strpos($output,'unknown_person') === false)
    {
        session_start(); 
        $outputimg = explode('.',$output);
        //setting session for account ID with image file name
      $_SESSION['accountid']=$outputimg[0];
//echo 'COOL'.$output.'TEST';
        header("Location: profile.php");
    }

    else
    {
        echo '<script language="javascript">';
        echo 'alert("We cannot find your face! \n Please Register & Login Again!")';
        echo '</script>';
    }
}
?>
<html lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Login FaceRecognition System- VSL Creations</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">

 <link href="css/styles.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<style type="text/css">
		body { font-family: Helvetica, sans-serif; }
		h2, h3 { margin-top:0; }
		form { margin-top: 15px; }
		form > input { margin-right: 15px; }
		#results { float:right; margin:20px; padding:20px; border:1px solid; background:#ccc; }
	</style>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="topnav" id="myTopnav">
      <a href="index.php" class="active"><img src="img/favicon.png"  width="30px"/></a>
<a href="features.php">WHY?</a>
      <a href="register.php">Register</a>
      <a href="login.php">Login</a>
      <a href="profile.php">Profile</a>
<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
    </div>
</nav>
	<table border=1><tr><td align="center">Live Streaming...</td></tr>
    <tr><td><div id="my_camera"></div></td></tr>
    </table>
	<!-- A button for taking snaps -->
    	<!-- First, include the Webcam.js JavaScript Library -->
	<script type="text/javascript" src="js/webcam.js"></script>
	<!-- Configure a few settings and attach camera -->
	<script language="JavaScript">
var w = window.innerWidth;
if(w>640){ w = 640;h=(w/2)*1.5;}

if(w<640)
{
	w=270;
	h=340;
}
		Webcam.set({
			width: w,
			height: h,
			image_format: 'jpeg',
			jpeg_quality: 90
		});
		Webcam.attach( '#my_camera' );
	</script>
	<form align="left" class="form-signin1" action="login.php" method="POST" enctype="multipart/form-data">
		
      <input type="submit" name="submit" value="Login" onClick="take_snapshot()" class="btn btn-lg btn-success">
	</form>
	<!-- Code to handle taking the snapshot and displaying it locally -->
	<script language="JavaScript">
		function take_snapshot() {
			// take snapshot and get image data
			Webcam.snap( function(data_uri) {
				Webcam.upload( data_uri, 'login.php');	
			} );
		}
	</script>
</body>
</html>
