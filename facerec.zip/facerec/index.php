<!--Copyright VSL Creations: http://www.vslcreations.com-->
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Smart FaceRecognition System- Innovatios Technology</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118206406-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118206406-1');
</script>


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </head>

  <body style="background: url(img/bg.jpeg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">

     <nav class="navbar navbar-default navbar-fixed-top">
<div class="topnav" id="myTopnav">    
     <a href="index.php" class="active"><img src="img/header.png"  height="35px"/></a>
<a href="features.php">WHY?</a>
      <a href="register.php">Register</a>
      <a href="login.php">Login</a>
      <a href="profile.php">Profile</a>

<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
      </div>

    </nav>

<div class="container">
<div class="jumbotron">
    <br/><h1> <img src="img/logo.jpg" width="100px"/>&nbsp;<b>Face</b>
    <a class="btn btn-lg btn-primary" href="register.php" role="button">Register</a>
    <a class="btn btn-lg btn-success" href="login.php" role="button">Login</a>
    <br/>Recognition<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "150px"></a></h1>
	<p><iframe width="560" height="315" src="https://www.youtube.com/embed/hhKdNjx6IDY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></p>
	<p><iframe width="560" height="315" src="https://www.youtube.com/embed/6xNnV6303Qo" frameborder="0" allowfullscreen></iframe>
    <br/><i>Take a picture of yourself and register with unique FaceID</i></p>
<div id="sfcq9ntrtx7n7m489gxy7s6pym187j37lcn"></div>
<script type="text/javascript" src="https://counter10.allfreecounter.com/private/counter.js?c=q9ntrtx7n7m489gxy7s6pym187j37lcn&down=async" async></script>
<noscript><a href="https://www.freecounterstat.com" title="hit counters"><img src="https://counter10.allfreecounter.com/private/freecounterstat.php?c=q9ntrtx7n7m489gxy7s6pym187j37lcn" border="0" title="hit counters" alt="hit counters"></a></noscript>


</div>   
</div> <!-- /container -->
  

</body></html>
