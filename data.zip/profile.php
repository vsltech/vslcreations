<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php
   session_start();
   $accountno = $_SESSION['accountid'];
   $accountno = substr_replace($accountno, "", -1);  //remove last white space charater
   if(!$_SESSION['accountid'])
   {
        echo '<script language="javascript">';
        echo 'alert("Please Login First!"); window.location.href="index.php"';
        echo '</script>';
    }
   if (isset($_POST['submit']))
    {
        unset($_SESSION['accountid']);  
        header("Location: index.php");
}

//IMG from local
$imgurl = "known_people/".$accountno.".jpg";

?>
<html class="gr__getbootstrap_com" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Smart FaceRecognition System- VSL Creations</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </head>
  <body style="background: url(img/bg.jpeg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="topnav" id="myTopnav">
      <a href="index.php" class="active"><img src="img/logo.png"  width="30px"/></a>
      <a href="register.php">Register</a>
      <a href="login.php">Login</a>
      <a href="profile.php">Profile</a>
      <a href="http://www.vslcreations.com/2017/12/smart-face-recognition-system-using.html">Manual</a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
    </div>
</nav>
<div class="container">
<div class="jumbotron">
    <br/><h1> <img src="img/logo.png" width="180px"/>&nbsp;<b>Face</b>
    <br/>Recognition</h1>
       <div class="row">
        <div class="col-xs-12 col-sm-6 col-md-6">
            <div class="well well-sm">
                <div class="row">
                    <div class="col-sm-6 col-md-4">
                        <img src="<?php echo $imgurl; ?>" class="img-rounded img-responsive"/>
                          
                    </div>
                    <div class="col-sm-6 col-md-8">
                       <h3>Welcome: <?php echo $accountno; ?></h4>
                        <h4>TEAM ID: <?php echo $accountno; ?></h4>
                        <h4>Account Number: <?php echo $accountno; ?></h4>
                        <h4>Aadhar Number: <?php echo $accountno; ?></h4>
                       <form action="profile.php" method="POST">
                        <input type="submit" name="submit" value="Logout" class="btn btn-danger btn-lg" role="button" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>   
</div>
</body>
</html>
