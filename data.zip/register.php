<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php
if(isset($_POST["submit"]))
{
    $name = $_POST["fname"];
    $name = $name."_".$_POST["lname"];  //Concatenating First_Last Name to avoid white space problem while POST with API
    $ac = $_POST["accountid"];
    $adhar = $_POST["adharid"]; 
    $extimg = explode('.', $_FILES["file"]["name"]);
    $imgname = $ac.'.'.end($extimg);
    if(is_dir("uploads") === false)
        mkdir("uploads");
    $target_file = "uploads/".$imgname;
    $known_people = "known_people/".$imgname;
    move_uploaded_file($_FILES["file"]["tmp_name"],$target_file);    
    //creating dataset of known_people in local server
       
    if(copy($target_file,$known_people))
    {   
        echo '<script language="javascript">alert("Successfully Registered!\nPlease login!")</script>';
        unlink($target_file);
        echo("<script>window.location = 'login.php';</script>");
    }
    else
    {
        echo '<script language="javascript">alert("Unsuccessful Registration!\nPlease try again!")</script>';
    }
}
?>
<!DOCTYPE html>
<html class="gr__getbootstrap_com" lang="en">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Register Face- Smart FaceRecognition System</title>
<!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/styles.css" rel="stylesheet">
      <link href="css/signin.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <script>
        function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
                x.className += " responsive";
            } else {
                x.className = "topnav";
            }
        }
        </script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script type="text/javascript">
        var _URL = window.URL || window.webkitURL;
            $(document).ready(function(){
                $('input[type="file"]').change(function(e){
                    var fileName = e.target.files[0].name;
                    //Remove comments to add size limits
		    //var size = e.target.files[0].size;
                    //var file = e.target.files[0];
                    
		    /*var img = new Image();
                    img.onload = function () {
                        if(this.width!=160 || this.height!=200){
                            alert('File '+fileName+': '+this.width + 'X' + this.height+' is incorrected!\nPlease select 160X200 resolution!');
                            }
                     };
                    img.src = _URL.createObjectURL(file); */
                    if (!fileName.match(/(?:gif|jpg|jpeg|png|bmp)$/)){
                        alert('File "' + fileName +  '" is invalid!\nPlease Select .jpg .jpeg .png');
                    }
                /*if(size>50000)
                {
                    alert('File "' + fileName +  '" exceeded size limit!\nPlease select less than 50kb');
                }*/
                });
            });
        </script>
  </head>
<body style="background: url(img/bg.jpeg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">
     <nav class="navbar navbar-default navbar-fixed-top">
        <div class="topnav" id="myTopnav">
          <a href="index.php" class="active"><img src="img/favicon.png"  width="25px"/></a>
          <a href="register.php">Register</a>
          <a href="login.php">Login</a>
          <a href="profile.php">Profile</a>
          <a href="http://www.vslcreations.com/2017/12/smart-face-recognition-system-using.html">Manual</a>
          <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
        </div>
    </nav>
    <div class="container" style="min-height:auto;">
      <form class="form-signin" action="" method="POST" enctype="multipart/form-data">
        <img src="img/logo.jpg" width="300px"/><h3> <b>FaceRecognition</b> System</h3>
       
        <input id="fname" name="fname" class="form-control" placeholder="FIRST NAME" required="yes" autofocus="" type="text">
        <input id="lname" name="lname" class="form-control" placeholder="LAST NAME" required="yes" autofocus="" type="text">
        <input id="accountid" name="accountid" class="form-control" placeholder="Employee ID" required="yes" type="text" maxlength="10" minlength="10">
        <input id="adharid" name="adharid" class="form-control" placeholder="Adhar ID" required="yes" type="text" pattern="\d*" maxlength="12" minlength="12">
	    <input type="file" name="file" class="form-control" multiple accept='image/*'>
    	<strong><i>(*Note: Enable limits for optimization in register.php Please upload your passport photo. Resolution: 160X200 and Size Limit: 50kb)</i></strong>
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="submit">Register</button>
      </form>
    </div> <!-- /container -->
</body>
</html>
