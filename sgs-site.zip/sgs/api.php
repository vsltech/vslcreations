<?php

$server ="ranjandentalclinic.com";
$user = "vsl";
$pass ="vslcreations.com";
$db = "gamesimulator";

$conn = new mysqli($server,$user,$pass,$db);

if($conn->connect_error)
{
	die("Connection failed: " . $conn_connect_error);
}
//echo "Connected<br>";
$sql = "Select * from sgs";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
	echo $row['userid'];
	echo $row['pass'];
	echo $row['regdate'];
	echo $row['expdate'];
}

?>
