<!--Copyright VSL Creations: http://www.vslcreations.com-->
<?php
   session_start();
   $accountno = $_SESSION['accountid'];
$server ="166.62.10.138";
$user = "vsltech";
$pass ="vslcreations.com";
$db = "gamesimulator";

$conn = new mysqli($server,$user,$pass,$db);

if($conn->connect_error)
{
	die("Connection failed: " . $conn_connect_error);
}
//echo "Connected<br>";
$sql = "select * from sgs where userid='".$accountno."'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()){
	$userid = $row['userid'];
	$macid = $row['macid'];
	$eid = $row['email'];
	$passd = $row['pass'];
	$regdate = $row['regdate'];
	$expdate =  $row['expdate'];
}
  
   if(!$_SESSION['accountid'])
   {
        echo '<script language="javascript">';
        echo 'alert("Please Login First!"); window.location.href="index.php"';
        echo '</script>';
    }
   if (isset($_POST['submit']))
    {
        unset($_SESSION['accountid']);  
        header("Location: index.php");
	}
   if (isset($_POST['mac']))
    {
		$macid1 = $_POST["macid1"];
		if($macid1=="")
		{
			        echo '<script language="javascript">';
					echo 'alert("Please Enter Valid MAC ID!"); window.location.href="profile.php"';
					echo '</script>';
		}

        $sql = "update sgs set macid='".$macid1."' where userid='".$accountno."'";
		if($conn->query($sql)==TRUE)
		{
			        echo '<script language="javascript">';
					echo 'alert("MAC ID Updated!"); window.location.href="profile.php"';
					echo '</script>';
		}
		else
		{
			        echo '<script language="javascript">';
					echo 'alert("Server ERROR!"); window.location.href="profile.php"';
					echo '</script>';
		}
	}

//$conn.close();
?>
<html class="gr__getbootstrap_com" lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.png">
    <title>Profile- SmartPhone Game Simulator</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/signin.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/navbar-fixed-top.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  <script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </head>
  <body style="background: url(img/bg.jpg) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;" data-gr-c-s-loaded="true">

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="topnav" id="myTopnav">
      <a href="index.php" class="active"><img src="img/favicon.png"  width="30px"/></a>
      <a href="register.php">Register</a>
      <a href="login.php">Login</a>
      <a href="profile.php">Profile</a>
<a href="https://github.com/vsltech/vslcreations/raw/master/sgs_client.zip" rel="nofollow"><img width = "100px" src="img/dl.png"></a>
<a href="https://transactions.sendowl.com/products/77844085/E4E427A7/purchase" rel="nofollow"><img width = "75px" src="https://transactions.sendowl.com/assets/external/buy-now.png"></a>

<a href="https://www.paypal.me/vslcreations"><img src="img/paypal_large.png" width = "100px"></a>
      <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
    </div>
</nav>
<div class="container" style="min-height:auto;">
<form class="form-signin" action="profile.php" method="POST">
   <label class="form-control"><img src="img/bg1.jpg" class="img-rounded img-responsive"/><h1><b>SmartPhone</b>
    <br/>Game Simulator</h1></label>

      <label class="form-control">Welcome: <?php echo $userid; ?><br>Email: <?php echo $eid; ?><br>
Password: <?php echo $passd; ?><br>Reg Date: <?php echo $regdate; ?><br>Exp Date:<?php echo $expdate; ?></label>
<label class="form-control">MAC ID: <?php echo $macid; ?></label>
<label class="form-control"><input id="macid1" name="macid1" class="form-control" placeholder="Update MAC ID" type="text" maxlength="17" minlength="17">
<br>
<input type="submit" name="mac" value="Update" class="btn btn-primary" role="button" />
                        <input type="submit" name="submit" value="Logout" class="btn btn-danger" role="button" />
</label>
                        </form>
                    
  
</div>
</body>
</html>
