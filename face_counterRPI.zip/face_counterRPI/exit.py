#CODED BY VSL Creations | email@vslcreations.com

import cv2,sys
import ftplib,datetime
import threading,csv
import urllib2,ssl
import numpy as np
from picamera.array import PiRGBArray
from picamera import PiCamera
 
# initialize the camera and grab a reference to the raw camera capture
camera = PiCamera()
camera.resolution = (640, 480)
camera.framerate = 32
rawCapture = PiRGBArray(camera, size=(640, 480))

#eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
font = cv2.FONT_HERSHEY_SIMPLEX

imgid = 0
for line in open('out/logentry.txt', 'r'):
    imgid=int(line)

if imgid==0:
    imgid = 1
print "Current IMG ID:",imgid

ext = '.jpg'
counter = 0
running = 1

def ftp(imgid):
        global running
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        imgid1 = imgid
        
        #imgid1 = imgid1+1
        session = ftplib.FTP('ranjandentalclinic.com','api@ranjandentalclinic.com','vslcreations.com')
        file = open('out/exitimg-'+str(imgid1)+ext,'rb')                  # file to send
        filedir = 'STOR '+'out/exitimg-'+str(imgid1)+ext
        session.storbinary(filedir, file)     # send the file
        #print 'out/exitimg-'+str(imgid1)+ext+' | STORED TO SERVER'
        
                
        file.close()                                    # close file and FTP
        session.quit()
        outime = str(datetime.datetime.now().strftime("%y-%m-%d_%H-%M-%S"))
        apiurl = "https://smartfacerec.ddns.net/api/exitapi.php?url=http://www.ranjandentalclinic.com/api/out/exitimg-"+str(imgid1)+ext+"&outime="+outime
        #print apiurl

        try:
		response = urllib2.urlopen(apiurl, context=ctx)
		data = response.read()
		print data
	except urllib2.HTTPError:
                pass

def variance_of_laplacian(image):
	# compute the Laplacian of the image and then return the focus
	# measure, which is simply the variance of the Laplacian
	return cv2.Laplacian(image, cv2.CV_64F).var()

#multi-threading
#t = threading.Thread(target=ftp)
#t.start()


# capture frames from the camera
for frame in camera.capture_continuous(rawCapture, format="bgr", use_video_port=True):
        	imgname = 'exitimg-'
        	(grabbed, i) = cam.read()
        	if not grabbed:
            		break

        	small_frame = cv2.resize(i, (640, 400))
                
                img = small_frame
                orig_img = img.copy()
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		fm = variance_of_laplacian(gray)
		#print type(fm)
		if fm>20:
		        cv2_faces = face_cascade.detectMultiScale(gray, 1.3, 5)
		        for (x,y,w,h) in cv2_faces:
		                cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)                  
		                cv2.putText(img,'FACE DETECTED',(x,y), font, 1,(255,255,255),2,cv2.LINE_AA)     
		                counter = counter+0.1
		                #print counter
		        cv2.imshow('img',img)
		        #Store img if face detected
		        if counter>0.3:
		                imgname = imgname + str(imgid) + ext
		                cv2.imwrite('out/'+imgname,orig_img)
		                ftp(imgid)
		        
		                imgid = imgid+1 
		                imgname = 'exitimg-'
		        
		                counter = 0
        	rawCapture.truncate(0)
        	if cv2.waitKey(10) & 0xff == ord('q'):
                	running = 0
                	break
f = open('out/logentry.txt', 'w')
f.write(str(imgid))
f.close()
cv2.destroyAllWindows()
